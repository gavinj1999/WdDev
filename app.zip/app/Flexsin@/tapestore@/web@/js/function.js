jQuery.noConflict();
jQuery.noConflict();
jQuery(document).ready(function(){
/*DropDown*/
jQuery(".upperSEK").click(function(){
	jQuery(".innerSEK").stop().slideToggle(300);
});

//Hover menuBar
jQuery(".mobnav").click(function(){
	jQuery(".menuMobile").toggleClass("opens");
	jQuery("body").toggleClass("bodyHidden");
});


/*DropDown*/
jQuery(".sideMenuBar > ul > li > a").click(function(){
 jQuery("ul.subMenu").slideUp(400);
 if(jQuery(this).hasClass("active")){
   jQuery(".sideMenuBar > ul > li > a").removeClass("active");
   jQuery(this).next("ul.subMenu").slideUp(400);
 }
 else{
   jQuery(".sideMenuBar > ul > li > a").removeClass("active");
   jQuery(this).addClass("active");
   jQuery(this).next("ul.subMenu").slideDown(400);
 }
});

/*DropDown (Acordian)*/
jQuery(".subMenu > li > a").click(function(){
 jQuery("ul.subInnerMenu").slideUp(400);
 if(jQuery(this).hasClass("active")){
   jQuery(".subMenu > li > a").removeClass("active");
   jQuery(this).next("ul.subInnerMenu").slideUp(400);
 }
 else{
   jQuery(".subMenu > li > a").removeClass("active");
   jQuery(this).addClass("active");
   jQuery(this).next("ul.subInnerMenu").slideDown(400);
 }
});

/*Menu Dropdown*/
jQuery(".menuBar ul > li").click(function(){
	 jQuery(".headsubmenuBar").stop().slideUp(300);								 
	 jQuery(this).find(".headsubmenuBar").stop().slideToggle(300);
});

/*--------tabs------*/
jQuery(".InformationTabs li a").on("click" , function(e){
	 e.preventDefault();
	var weddInd = jQuery(this).attr('href');
	jQuery(".tabsContent").hide(0);
	jQuery(weddInd).show(0);
	jQuery(".InformationTabs li a").removeClass('active');
	jQuery(this).addClass('active');
});

});

/**ThumbSlider**/
/*jQuery(document).ready(function(){
  jQuery('.petSlider').owlCarousel({
    thumbs: true,
    thumbsPrerendered: true,
	loop:true,
    margin:0,
    nav:true,
	items:1,
	autoplay:false
	
  });
});*/



