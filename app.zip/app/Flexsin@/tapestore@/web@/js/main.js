 jQuery.noConflict();
jQuery(document).ready(function($){
jQuery('#image').cropper({
  data: {
    width: 592,
    height: 444
  }
});

var proIId = jQuery('input[name=product]').val();

  'use strict';

  var console = window.console || { log: function () {} };
  var URL = window.URL || window.webkitURL;
  var $image = jQuery('#image');
  var $download = jQuery('#download');
  var $dataX = jQuery('#dataX');
  var $dataY = jQuery('#dataY');
  var $dataHeight = jQuery('#dataHeight');
  var $dataWidth = jQuery('#dataWidth');
  var $dataRotate = jQuery('#dataRotate');
  var $dataScaleX = jQuery('#dataScaleX');
  var $dataScaleY = jQuery('#dataScaleY');
  var options = {
    aspectRatio: 1 / 1,
    preview: '.img-preview',
    crop: function (e) {
      $dataX.val(Math.round(e.x));
      $dataY.val(Math.round(e.y));
          //$dataHeight.val(Math.round(e.height));
         // $dataWidth.val(Math.round(e.width));
         $dataRotate.val(e.rotate);
         $dataScaleX.val(e.scaleX);
         $dataScaleY.val(e.scaleY);
       }
     };
     var originalImageURL = $image.attr('src');
     var uploadedImageURL;

     /*******************Outer height***************************************/   

     jQuery('#dataHeightOuter').keyup(function(){
      jQuery('input[name=material]').prop('checked', false);
      jQuery('#changedPrice').html(0);
      jQuery('#productPrice').val(0);
      var scalex = jQuery('#dataX').val();
      var scaley = jQuery('#dataY').val();
      var width = parseInt(jQuery('#dataWidthOuter').val());
      var height = parseInt(jQuery('#dataHeightOuter').val());
        var hiddenWidth = parseInt(jQuery('#hiddenWidth').val());
  var hiddenHeight = parseInt(jQuery('#hiddenHeight').val());
      var imageData =$('#image').cropper('getImageData');
      var getCustomContainerData =$('#image').cropper('getCustomContainerData');
      console.log(getCustomContainerData);
      var h = getCustomContainerData.containerHeight;
      var wi = getCustomContainerData.containerWidth;
   
      jQuery('#upperDimension').html(width);
      jQuery('#leftDimension').html(height);
       //jQuery('#leftDimension').html(height);
      if(height > hiddenHeight || width > hiddenWidth){
          jQuery('#dimensionError').attr('style','font-size:10px;color:red;display:block');
      }else{
         jQuery('#dimensionError').attr('style','font-size:10px;color:red;display:none');
      }
      /**************Price Calculation*************************/
      var calwidth = width/100;
      var calheight = height/100;
      var calPrice = calwidth*calheight*295 ;
      calPrice = Math.floor(parseInt(calPrice)) + ':-';
      var calprice = calwidth*calheight*295;
      if(!isNaN(calprice)){
      jQuery('#productPrice').val(calprice);
      jQuery('#changedPrice').html(calPrice);
    }
      /******************************************/
      
      if(height > width){
        var ratioo =  width/height;
        
        //var naturalwidth = imageData["naturalwidth"];
        var widthh = parseInt(ratioo*wi);
        console.log('widthh');
        console.log(widthh);
        jQuery('#dataHeight').val(h);
        jQuery('#dataWidth').val(widthh);
      }else if(width > height){
        var ratioo =  height/width;
        var heightt = parseInt(ratioo*h);
        console.log('height');
        console.log(heightt);
        if(heightt != 'undefined'){
          jQuery('#dataHeight').val(heightt);
          jQuery('#dataWidth').val(wi);

        }

      }else if(width == height){

        var crHt;
        var crWt;
        if(h > wi){
          var crHt = wi;
          var crWt = wi;
        }else if(wi > h){
          crHt = h;
          crWt = h;
        }else if(wi == h){
          crHt = h;
          crWt = wi;
        }
        jQuery('#dataHeight').val(crHt);
        jQuery('#dataWidth').val(crWt);
      }
      jQuery('.custom_height').val(height);
      jQuery('.custom_width').val(width);
      jQuery('.custom_scalex').val(scalex);
      jQuery('.custom_scaley').val(scaley);
      $image.cropper('customCrop');

    });
/*******************Outer Width***************************************/

jQuery('#dataWidthOuter').keyup(function(){
  jQuery('input[name=material]').prop('checked', false);
  jQuery('#changedPrice').html(0);
  jQuery('#productPrice').val(0);
  var scalex = jQuery('#dataX').val();
  var scaley = jQuery('#dataY').val();
  var width = parseInt(jQuery('#dataWidthOuter').val());
  var height = parseInt(jQuery('#dataHeightOuter').val());
  var hiddenWidth = parseInt(jQuery('#hiddenWidth').val());
  var hiddenHeight = parseInt(jQuery('#hiddenHeight').val());
  var getCustomContainerData =$('#image').cropper('getCustomContainerData');
  var imageData =$('#image').cropper('getImageData'); 
   console.log(getCustomContainerData);
   var h = getCustomContainerData.containerHeight;
   var wi = getCustomContainerData.containerWidth;
   var naturalwidth = imageData["naturalwidth"];
jQuery('#upperDimension').html(width);
      jQuery('#leftDimension').html(height);
      if(height > hiddenHeight || width > hiddenWidth){
		if(hiddenHeight > 0){
          jQuery('#dimensionError').attr('style','font-size:10px;color:red;display:block');
		}
      }else{
         jQuery('#dimensionError').attr('style','font-size:10px;color:red;display:none');
      }
   /**************Price Calculation*************************/
      var calwidth = width/100;
      var calheight = height/100;
      var calPrice = calwidth*calheight*295 ;
      calPrice = Math.floor(parseInt(calPrice)) + ':-';
      var calprice = calwidth*calheight*295;
      if(!isNaN(calprice)){
      jQuery('#productPrice').val(calprice);
      jQuery('#changedPrice').html(calPrice);
    }
  /******************************************/
  if(height > width){
   var ratioo =  width/height;
   var imageData =$('#image').cropper('getImageData');
   
   var widthh = parseInt(ratioo*wi);
   jQuery('#dataHeight').val(h);
   jQuery('#dataWidth').val(widthh);
 }else if(width > height){

   var ratioo =  height/width;
   var heightt = parseInt(ratioo*h);
   if(heightt != 'undefined'){
    jQuery('#dataHeight').val(heightt);
    jQuery('#dataWidth').val(wi);

  }
}else if(width == height){
  var crHt;
  var crWt;
  if(h > wi){
    var crHt = wi;
    var crWt = wi;
  }else if(wi > h){
    crHt = h;
    crWt = h;
  }else if(wi == h){
          crHt = h;
          crWt = wi;
        }
  jQuery('#dataHeight').val(crHt);
  jQuery('#dataWidth').val(crWt);
}
jQuery('.custom_height').val(height);
jQuery('.custom_width').val(width);
jQuery('.custom_scalex').val(scalex);
jQuery('.custom_scaley').val(scaley);
$image.cropper('customCrop');

});
jQuery('input[name=material]').change(function(){
  var width = jQuery('#dataWidthOuter').val();
  var height = jQuery('#dataHeightOuter').val();
  var material = jQuery('input[name=material]:checked').val();
  jQuery('.custom_material').val(material);
  if(material != ""){
    var calwidth = width/100;
    var calheight = height/100;
    var calPrice = calwidth*calheight*material ;
    calPrice = Math.floor(parseInt(calPrice)) + ':-';
    var calprice = calwidth*calheight*material;
    jQuery('#productPrice').val(calprice);
    jQuery('#changedPrice').html(calPrice);

  }/*else if(material == "Premium Wall Mural"){
    var calwidth = width/100;
    var calheight = height/100;
    var calPrice = calwidth*calheight*395;
    calPrice = Math.floor(parseInt(calPrice)) + ':-';
    var calprice = calwidth*calheight*395;
    jQuery('#changedPrice').html(calPrice);
    jQuery('#productPrice').val(calprice);
  }*/
});

jQuery('input[name=mirror]').change(function(){
  if(jQuery('input[name=mirror]').is(':checked')){
    jQuery('.custom_mirror').val('Yes');
  }else{
    jQuery('.custom_mirror').val('No');
  }
});

  // Tooltip
  //jQuery('[data-toggle="tooltip"]').tooltip();

if(proIId == 19){
  // Cropper
 /* $image.on({
    'build.cropper': function (e) {
      console.log(e.type);
    },
    'built.cropper': function (e) {
      console.log(e.type);
    },
    'cropstart.cropper': function (e) {
      console.log(e.type, e.action);
      
    },
    'cropmove.cropper': function (e) {
      console.log(e.type, e.action);*/

    /* var d =  $image.cropper('getCropBoxData');
   /*  jQuery('#dataWidthOuter').val(d.width);
     jQuery('#dataWidth').val(d.width);
     jQuery('#dataHeightOuter').val(d.height);
     jQuery('#dataHeight').val(d.height);*/
  /* },
   'cropend.cropper': function (e) {
    console.log(e.type, e.action);
  },
  'crop.cropper': function (e) {
    console.log(e.type, e.x, e.y, e.width, e.height, e.rotate, e.scaleX, e.scaleY);
  },
  'zoom.cropper': function (e) {
    console.log(e.type, e.ratio);
  }
}).cropper(options);*/
}

  // Buttons
  if (!$.isFunction(document.createElement('canvas').getContext)) {
    jQuery('button[data-method="getCroppedCanvas"]').prop('disabled', true);
  }

  if (typeof document.createElement('cropper').style.transition === 'undefined') {
    jQuery('button[data-method="rotate"]').prop('disabled', true);
    jQuery('button[data-method="scale"]').prop('disabled', true);
  }


  // Download
  if (typeof $download[0].download === 'undefined') {
    $download.addClass('disabled');
  }


  // Options
  jQuery('.docs-toggles').on('change', 'input', function () {
    var $this = jQuery(this);
    var name = $this.attr('name');
    var type = $this.prop('type');
    var cropBoxData;
    var canvasData;

    if (!$image.data('cropper')) {
      return;
    }

    if (type === 'checkbox') {
      options[name] = $this.prop('checked');
      cropBoxData = $image.cropper('getCropBoxData');
      canvasData = $image.cropper('getCanvasData');

      options.built = function () {
        $image.cropper('setCropBoxData', cropBoxData);
        $image.cropper('setCanvasData', canvasData);
      };
    } else if (type === 'radio') {
      options[name] = $this.val();
    }

    $image.cropper('destroy').cropper(options);
  });


  // Methods
  jQuery('.docs-buttons').on('click', '[data-method]', function () {

    var $this = jQuery(this);
    var data = $this.data();
    var $target;
    var result;

    if ($this.prop('disabled') || $this.hasClass('disabled')) {
      return;
    }

    if ($image.data('cropper') && data.method) {
      data = $.extend({}, data); // Clone a new one

      if (typeof data.target !== 'undefined') {
        $target = jQuery(data.target);

        if (typeof data.option === 'undefined') {
          try {
            data.option = JSON.parse($target.val());
          } catch (e) {
            console.log(e.message);
          }
        }
      }

      if (data.method === 'rotate') {
        $image.cropper('clear');
      }

      result = $image.cropper(data.method, data.option, data.secondOption);

      if (data.method === 'rotate') {
        $image.cropper('crop');
      }

      switch (data.method) {
        case 'scaleX':
        case 'scaleY':
        jQuery(this).data('option', -data.option);
        

        break;

        case 'destroy':
        if (uploadedImageURL) {
            $image.cropper('customCrop');
          URL.revokeObjectURL(uploadedImageURL);
          uploadedImageURL = '';
          $image.attr('src', originalImageURL);
        }

        break;
      }

      if ($.isPlainObject(result) && $target) {
        try {
          $target.val(JSON.stringify(result));
        } catch (e) {
          console.log(e.message);
        }
      }

    }
  });

/******Custom download****/
jQuery('.docs-buttons').on('click', '[data-method]', function () {
  var $this = jQuery(this);
  var data = $this.data();
  var $target;
  var result;

  if ($this.prop('disabled') || $this.hasClass('disabled')) {
    return;
  }

  if ($image.data('cropper') && data.method) {
      data = $.extend({}, data); // Clone a new one

      if (typeof data.target !== 'undefined') {
        $target = jQuery(data.target);

        if (typeof data.option === 'undefined') {
          try {
            data.option = JSON.parse($target.val());
          } catch (e) {
            console.log(e.message);
          }
        }
      }

      if (data.method === 'rotate') {
        $image.cropper('clear');
      }

      result = $image.cropper(data.method, data.option, data.secondOption);

      if (data.method === 'rotate') {
        $image.cropper('crop');
      }
      if (data.method === 'getCroppedCanvas') {
        $image.cropper('crop');


        if (result) {

            // Bootstrap's Modal
            //jQuery('#getCroppedCanvasModal').modal().find('.modal-body').html(result);

            if (!$download.hasClass('disabled')) {
              //jQuery('#gettcCropBoxData').click();
              var dataURL = result.toDataURL('image/jpeg');
              jQuery.ajax({
                type: "POST",
                url: "Image/index/download",
                data: { 
                 imgBase64: dataURL
               },
               success:function(data) {
                jQuery('.custom_imageUrl').text(data);

                jQuery('#product-addtocart-button').click();
              }
            }).done(function(o) {
              console.log('saved'); 
                      // If you want the file to be visible in the browser 
                      // - please modify the callback in javascript. All you
                      // need is to return the url to the file, you just saved 
                      // and than put the image in your browser.
                    });
          }
        }

      }





    }
  });

/******Custom download****/


  // Keyboard
  jQuery(document.body).on('keydown', function (e) {

    if (!$image.data('cropper') || this.scrollTop > 300) {
      return;
    }

    switch (e.which) {
      case 37:
      e.preventDefault();
      $image.cropper('move', -1, 0);
      break;

      case 38:
      e.preventDefault();
      $image.cropper('move', 0, -1);
      break;

      case 39:
      e.preventDefault();
      $image.cropper('move', 1, 0);
      break;

      case 40:
      e.preventDefault();
      $image.cropper('move', 0, 1);
      break;
    }

  });


  // Import image
  var $inputImage = jQuery('#inputImage');
jQuery('#uploadError').attr('style','font-size:10px;color:red;display:none');
  if (URL) {
    $inputImage.change(function () {
      var reader = new FileReader;

        reader.onload = function() {
            var image = new Image();

            image.src = reader.result;

            image.onload = function() {
                var uploadWidth = image.width;
                var uploadHeight = image.height;
                console.log(uploadWidth);
if(uploadWidth < 3000 || uploadHeight < 3000 ){
                imageChange('http://tapetstore.flexsin.org/pub/media/catalog/product/cache/1/image/700x700/e9c3970ab036de70892d86c6d221abfe/d/e/demowallpapercrop_2.jpg');
jQuery('#uploadError').attr('style','color:red;display:block');

}

            };

        };

        reader.readAsDataURL(this.files[0]);
     console.log($image.cropper('defaultCrop'));
   
      var files = this.files;
      var file;

      if (!$image.data('cropper')) {
        return;
      }

      if (files && files.length) {
        file = files[0];

        if (/^image\/\w+$/.test(file.type)) {
          if (uploadedImageURL) {
            URL.revokeObjectURL(uploadedImageURL);
          }

          uploadedImageURL = URL.createObjectURL(file);
          $image.cropper('destroy').attr('src', uploadedImageURL).cropper(options);
          $inputImage.val('');
        } else {
          window.alert('Please choose an image file.');
        }
      }
    });
  } else {
    //$inputImage.prop('disabled', true).parent().addClass('disabled');
  }


});

function imageChange(imgurl){
jQuery('#upperDimension').html('');
jQuery('#leftDimension').html('');
jQuery('#dataWidthOuter').val('');
jQuery('#dataHeightOuter').val('');
jQuery('#productPrice').val(0);
jQuery('#changedPrice').html(0);
  var $dataX = jQuery('#dataX');
  var $dataY = jQuery('#dataY');
  var $dataHeight = jQuery('#dataHeight');
  var $dataWidth = jQuery('#dataWidth');
  var $image = jQuery('#image');
  jQuery('.custom_filter').text(imgurl);
  var options = {
    aspectRatio: 16 / 9,
    preview: '.img-preview',
    crop: function (e) {
      $dataX.val(Math.round(e.x));
      $dataY.val(Math.round(e.y));
      $dataHeight.val(Math.round(e.height));
      $dataWidth.val(Math.round(e.width));
      $dataRotate.val(e.rotate);
      $dataScaleX.val(e.scaleX);
      $dataScaleY.val(e.scaleY);
    }
  };
  $image.cropper('destroy').attr('src', imgurl);//.cropper(options);
  jQuery('#image').cropper({
  data: {
    width: 592,
    height: 444
  }
});
}
function imageChangedropdown(thiss){
jQuery('#upperDimension').html('');
jQuery('#leftDimension').html('');
jQuery('#dataWidthOuter').val('');
jQuery('#dataHeightOuter').val('');
jQuery('#productPrice').val(0);
jQuery('#changedPrice').html(0);
  var imgurl = jQuery(thiss).val();
  var $dataX = jQuery('#dataX');
  var $dataY = jQuery('#dataY');
  var $dataHeight = jQuery('#dataHeight');
  var $dataWidth = jQuery('#dataWidth');
  var $image = jQuery('#image');
  
  jQuery('.custom_filter').text(imgurl);
  var options = {
    aspectRatio: 16 / 9,
    preview: '.img-preview',
    crop: function (e) {
      $dataX.val(Math.round(e.x));
      $dataY.val(Math.round(e.y));
      $dataHeight.val(Math.round(e.height));
      $dataWidth.val(Math.round(e.width));
      $dataRotate.val(e.rotate);
      $dataScaleX.val(e.scaleX);
      $dataScaleY.val(e.scaleY);
    }
  };
  $image.cropper('destroy').attr('src', imgurl);//.cropper(options);
  jQuery('#image').cropper({
  data: {
    width: 592,
    height: 444
  }
});
}
